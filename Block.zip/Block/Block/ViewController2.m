//
//  ViewController2.m
//  Block
//
//  Created by  刘雅兰 on 17/11/2.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//

#import "ViewController2.h"
@interface ViewController2 ()
@property (weak, nonatomic) IBOutlet UITextField *startValueField;
- (IBAction)startValueClick:(id)sender;
@end
@implementation ViewController2
- (void)viewDidLoad {
    [super viewDidLoad];
//    
//    [self methodWithBlock:^(NSString *secondString) {
//        NSLog(@"%@",secondString);
//    }];
    // Do any additional setup after loading the view from its nib.
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)startValueClick:(id)sender {
    
     [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(void)showTheResultToFirst:(BlockViewBlock)block {
    self.passValue = block;
}


-(void)viewWillDisappear:(BOOL)animated {
    
    if (self.passValue != nil) {
        self.passValue(self.startValueField.text);
    }
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
   // _passValue(@"字符串");
}


//-(void)methodWithBlock:(BlockViewBlock)block{
//    block(@"methodWithBlock 调用了");
//}

@end
