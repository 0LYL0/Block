//
//  ViewController2.h
//  Block
//
//  Created by  刘雅兰 on 17/11/2.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void (^BlockViewBlock)(NSString *secondString);

@interface ViewController2 : UIViewController


@property (nonatomic , copy) BlockViewBlock passValue;


-(void)showTheResultToFirst:(BlockViewBlock) block;


@end
