//
//  ViewController1.m
//  Block
//
//  Created by  刘雅兰 on 17/11/2.
//  Copyright © 2017年  刘雅兰. All rights reserved.
//

#import "ViewController1.h"
#import "ViewController2.h"
@interface ViewController1 ()

@property (weak, nonatomic) IBOutlet UILabel *blockLabel;
- (IBAction)blockClick:(id)sender;
@end

@implementation ViewController1

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)blockClick:(id)sender {
    
    ViewController2 *blockVC =[[ViewController2 alloc] init];
    //防止循环引用
    //__weak ViewController1 *weakSelf = self;
    [blockVC showTheResultToFirst:^(NSString *secondString) {
        _blockLabel.text = secondString;
    }];
    [self presentViewController:blockVC animated:YES completion:nil];
    
}
@end
